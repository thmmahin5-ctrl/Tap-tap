package com.example.tapcounter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Purple = Color(0xFF6C5CE7)
private val Blue = Color(0xFF0984E3)
private val Bg = Color(0xFFF4F5FB)
private val Ink = Color(0xFF1E1F2B)
private val Muted = Color(0xFF8A8DA0)
private val Grad = Brush.linearGradient(listOf(Purple, Blue))
private val bn = Locale("bn")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf(0) }

    fun change(d: Int) {
        Store.add(ctx, d)
        tick++
        scope.launch { refreshAll(ctx) }
    }

    val all = remember(tick) { Store.all(ctx) }
    val today = LocalDate.now()
    val todayTaps = all.filter { it.date() == today }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg).statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Hero(todayTaps.sumOf { it.delta }, today, { change(-1) }, { change(1) }) }
        item { TodayStats(todayTaps) }
        item { Tabs(tab) { tab = it } }
        when (tab) {
            0 -> todayItems(todayTaps)
            1 -> rangeItems(all, (0L..6L).map { today.minusDays(it) })
            else -> rangeItems(all, (0 until today.dayOfMonth).map { today.minusDays(it.toLong()) })
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun Hero(count: Int, date: LocalDate, onMinus: () -> Unit, onPlus: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Grad)
            .padding(24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("আজকের কাউন্ট", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
                Text(
                    date.format(DateTimeFormatter.ofPattern("d MMMM, yyyy", bn)),
                    color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp
                )
                Text(count.toString(), color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Bold)
            }
            RoundBtn("−", 52, false, onMinus)
            Spacer(Modifier.width(12.dp))
            RoundBtn("+", 68, true, onPlus)
        }
    }
}

@Composable
fun RoundBtn(label: String, size: Int, filled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(size.dp)
            .clip(CircleShape)
            .background(if (filled) Color.White else Color.White.copy(alpha = 0.25f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (filled) Purple else Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TodayStats(taps: List<Tap>) {
    val ups = taps.filter { it.delta > 0 }
    val first = if (ups.isNotEmpty()) Store.fmtTime(ups.first().time) else "-"
    val last = if (ups.isNotEmpty()) Store.fmtTime(ups.last().time) else "-"
    val dur = if (ups.size >= 2) Store.fmtDuration(Store.span(taps)) else "-"
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("প্রথম ট্যাপ", first, Modifier.weight(1f))
        StatCard("শেষ ট্যাপ", last, Modifier.weight(1f))
        StatCard("মোট সময়", dur, Modifier.weight(1f))
    }
}

@Composable
fun Tabs(selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White)
            .padding(4.dp)
    ) {
        listOf("আজ", "সপ্তাহ", "মাস").forEachIndexed { i, t ->
            val on = i == selected
            Box(
                Modifier.weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Grad else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(t, color = if (on) Color.White else Muted, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

fun LazyListScope.todayItems(taps: List<Tap>) {
    if (taps.isEmpty()) {
        item { EmptyCard("আজ এখনো কোনো ট্যাপ নেই। + চাপুন!") }
        return
    }
    var n = 0
    val rows = taps.map { t ->
        if (t.delta > 0) { n++; Triple(n.toString(), t, true) } else Triple("−", t, false)
    }
    item { Text("আজকের ট্যাপের তালিকা", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
    items(rows) { r -> TapRow(r.first, r.second, r.third) }
}

@Composable
fun TapRow(label: String, t: Tap, up: Boolean) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape)
                    .background(if (up) Grad else Brush.linearGradient(listOf(Color(0xFFFFE3E3), Color(0xFFFFE3E3)))),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (up) Color.White else Color(0xFFD63031), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(Store.fmtTime(t.time), color = Ink, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(
                if (up) "+1" else "−1",
                color = if (up) Purple else Color(0xFFD63031),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

fun LazyListScope.rangeItems(all: List<Tap>, days: List<LocalDate>) {
    val lists = days.map { d -> all.filter { it.date() == d } }
    val counts = lists.map { l -> l.sumOf { it.delta } }
    val total = counts.sum()
    val best = (counts.maxOrNull() ?: 0)
    val maxForBar = best.coerceAtLeast(1)
    val avg = "%.1f".format(total.toDouble() / days.size)

    item {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("মোট", total.toString(), Modifier.weight(1f))
            StatCard("গড়/দিন", avg, Modifier.weight(1f))
            StatCard("সেরা দিন", best.toString(), Modifier.weight(1f))
        }
    }
    items(days.indices.toList()) { i ->
        val l = lists[i]
        val span = if (l.count { it.delta > 0 } >= 2) Store.fmtDuration(Store.span(l)) else "-"
        DayRow(days[i], counts[i], maxForBar, span)
    }
}

@Composable
fun DayRow(date: LocalDate, count: Int, max: Int, span: String) {
    val frac = (count.coerceAtLeast(0).toFloat() / max).coerceIn(0f, 1f)
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        date.format(DateTimeFormatter.ofPattern("d MMM", bn)),
                        color = Ink, fontWeight = FontWeight.Bold
                    )
                    Text(
                        date.dayOfWeek.getDisplayName(java.time.format.TextStyle.FULL, bn),
                        color = Muted, fontSize = 12.sp
                    )
                }
                Text(count.toString(), color = Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.fillMaxWidth().height(8.dp)
                    .clip(RoundedCornerShape(4.dp)).background(Color(0xFFEDEEF7))
            ) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Grad))
            }
            Spacer(Modifier.height(8.dp))
            Text("প্রথম→শেষ: $span", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun EmptyCard(msg: String) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
            Text(msg, color = Muted)
        }
    }
}
