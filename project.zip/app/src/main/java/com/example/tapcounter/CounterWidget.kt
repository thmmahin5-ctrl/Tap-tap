package com.example.tapcounter

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.state.updateAppWidgetState
import androidx.glance.background
import androidx.glance.currentState
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import java.time.LocalDate

private val REFRESH_KEY = longPreferencesKey("refresh")

suspend fun refreshAll(context: Context) {
    val widget = CounterWidget()
    val ids = GlanceAppWidgetManager(context).getGlanceIds(CounterWidget::class.java)
    ids.forEach { id ->
        updateAppWidgetState(context, id) { it[REFRESH_KEY] = System.currentTimeMillis() }
        widget.update(context, id)
    }
}

class CounterWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { Content(context) }
    }
}

@Composable
private fun Content(c: Context) {
    val prefs = currentState<Preferences>()
    @Suppress("UNUSED_VARIABLE")
    val tick = prefs[REFRESH_KEY] ?: 0L

    val today = Store.day(c, LocalDate.now())
    val count = today.sumOf { it.delta }
    val ups = today.filter { it.delta > 0 }
    val span = if (ups.size >= 2) Store.fmtDuration(Store.span(today)) else "-"

    val white = ColorProvider(Color.White)
    val soft = ColorProvider(Color(0xCCFFFFFF))
    val purple = ColorProvider(Color(0xFF6C5CE7))

    Row(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg))
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .clickable(actionStartActivity<MainActivity>()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = GlanceModifier.defaultWeight()) {
            Text("আজকের কাউন্ট", style = TextStyle(color = soft, fontSize = 12.sp))
            Text(count.toString(), style = TextStyle(color = white, fontSize = 44.sp, fontWeight = FontWeight.Bold))
            Text("প্রথম→শেষ: $span", style = TextStyle(color = soft, fontSize = 11.sp))
        }
        Box(
            modifier = GlanceModifier
                .size(46.dp)
                .background(ImageProvider(R.drawable.btn_minus))
                .clickable(actionRunCallback<MinusAction>()),
            contentAlignment = Alignment.Center
        ) {
            Text("−", style = TextStyle(color = white, fontSize = 26.sp, fontWeight = FontWeight.Bold))
        }
        Spacer(GlanceModifier.width(10.dp))
        Box(
            modifier = GlanceModifier
                .size(58.dp)
                .background(ImageProvider(R.drawable.btn_plus))
                .clickable(actionRunCallback<PlusAction>()),
            contentAlignment = Alignment.Center
        ) {
            Text("+", style = TextStyle(color = purple, fontSize = 30.sp, fontWeight = FontWeight.Bold))
        }
    }
}

class PlusAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        Store.add(context, 1)
        refreshAll(context)
    }
}

class MinusAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        Store.add(context, -1)
        refreshAll(context)
    }
}

class CounterWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = CounterWidget()
}
